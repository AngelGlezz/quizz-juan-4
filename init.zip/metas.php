<?php
	$metas = array(
		"villamelon" => array(
			"title" => "para verdaderos conocedores de la Champions",
			"description" => "Villamelón le dicen",
			"image" => "images/metas/3.png" 
		),
		"sinpalabras" => array(
			"title" => "para verdaderos conocedores de la Champions",
			"description" => "Sin palabras",
			"image" => "images/metas/2.png" 
		)
		,
		"maso" => array(
			"title" => "para verdaderos conocedores de la Champions",
			"description" => "Ahí la llevas",
			"image" => "images/metas/1.png" 
		)
		,
		"champion" => array(
			"title" => "para verdaderos conocedores de la Champions",
			"description" => "La Champions eres tú",
			"image" => "images/metas/0.png" 
		)
	);